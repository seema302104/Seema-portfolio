import { useEffect, useState } from 'react';
import {
  ArrowDown,
  ArrowDownRight,
  ArrowRight,
  BrainCircuit,
  Braces,
  Code2,
  Cpu,
  FileText,
  Linkedin,
  Mail,
  Menu,
  ScanLine,
  Sparkles,
  X,
  Wrench,
} from 'lucide-react';

type Project = {
  title: string;
  category: string;
  description: string;
  stack: string;
  detail: string;
  tone: string;
  icon: typeof BrainCircuit;
};

const navItems = [
  ['Home', '#home'],
  ['About me', '#about'],
  ['Skills', '#skills'],
  ['My projects', '#projects'],
  ['Internship', '#experience'],
];

const skillGroups = [
  {
    name: 'Web Development',
    icon: Code2,
    skills: ['HTML', 'CSS', 'JavaScript', 'Responsive Design', 'Next.js', 'Tailwind CSS'],
  },
  {
    name: 'Programming and Backend',
    icon: Braces,
    skills: ['Python', 'FastAPI', 'Django', 'REST APIs', 'SQL', 'PostgreSQL'],
  },
  {
    name: 'AI and Machine Learning',
    icon: BrainCircuit,
    skills: ['Machine Learning', 'Deep Learning', 'YOLO', 'Computer Vision', 'OCR', 'Generative AI', 'AI Agents', 'OpenCV'],
  },
  {
    name: 'Tools',
    icon: Wrench,
    skills: ['VS Code', 'Postman', 'n8n', 'Streamlit'],
  },
];

const projects: Project[] = [
  {
    title: 'AI Career Mentor',
    category: 'Applied AI · Career tools',
    description: 'A practical AI project exploring how personalized guidance can make career planning feel more approachable.',
    stack: 'AI / ML · Python',
    detail: 'AI Career Mentor brings together Seema’s interest in artificial intelligence and real-world problem solving. The project explores an approachable way to support career discovery and next-step planning with AI.',
    tone: 'purple',
    icon: BrainCircuit,
  },
  {
    title: 'YOLO Object Detection',
    category: 'Computer vision · Detection',
    description: 'An object-detection project using YOLO to explore how computer vision interprets the world around us.',
    stack: 'Computer vision · YOLO',
    detail: 'YOLO Object Detection is a hands-on exploration of computer vision: identifying objects in visual input and making machine-learning concepts tangible through a working project.',
    tone: 'cyan',
    icon: ScanLine,
  },
  {
    title: 'Invoice AI',
    category: 'Applied AI · Document workflows',
    description: 'An AI project focused on making document and invoice workflows more useful through intelligent automation.',
    stack: 'AI / ML · Python',
    detail: 'Invoice AI explores how applied AI can help with everyday document workflows. It reflects Seema’s interest in taking emerging technology and turning it toward practical use.',
    tone: 'rose',
    icon: FileText,
  },
];

function App() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  // Reveal sections when they enter the viewport; keep all content visible for reduced motion.
  useEffect(() => {
    const elements = document.querySelectorAll<HTMLElement>('.reveal');
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion || !('IntersectionObserver' in window)) {
      elements.forEach((element) => element.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      }),
      { threshold: 0.12 },
    );
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  // Escape closes project details and the mobile navigation.
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setSelectedProject(null);
        setMenuOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  function closeMenu() {
    setMenuOpen(false);
  }

  return (
    <main className="portfolio" data-testid="portfolio-page">
      <header className="topbar" data-testid="site-header">
        <div className="topbar-inner">
          <a className="brand" href="#home" onClick={closeMenu} data-testid="link-brand">
            SV<b>.</b>
          </a>
          <button
            className="menu-toggle"
            type="button"
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
            data-testid="button-mobile-menu"
          >
            {menuOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
          <nav className={`nav-links${menuOpen ? ' nav-open' : ''}`} aria-label="Main navigation" data-testid="navigation-main">
            {navItems.map(([label, href]) => (
              <a href={href} key={href} onClick={closeMenu} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}>
                {label}
              </a>
            ))}
            <a className="nav-contact" href="#contact" onClick={closeMenu} data-testid="link-nav-contact">Contact me <ArrowDownRight size={14} /></a>
          </nav>
        </div>
      </header>

      <section className="hero" id="home" data-testid="section-home">
        <div className="ambient ambient-purple" style={{ top: 100, left: '-170px' }} />
        <div className="ambient ambient-cyan" style={{ top: 255, right: '-170px' }} />
        <div className="section-wrap hero-grid">
          <div className="hero-content">
            <div className="eyebrow reveal" data-testid="text-hero-kicker">Curious mind. Practical builder.</div>
            <h1 className="reveal reveal-delay-1" data-testid="text-hero-title">
              Hello, I’m
              <span>Seema Visavadiya.</span>
            </h1>
            <p className="hero-copy reveal reveal-delay-2" data-testid="text-hero-introduction">
              A <strong>fresher Web Developer</strong> and <strong>AI/ML Developer</strong> building at the intersection of useful technology and thoughtful experiences.
            </p>
            <div className="hero-actions reveal reveal-delay-3">
              <a className="button button-primary" href="#projects" data-testid="button-explore-projects">
                Explore my work <ArrowRight size={16} />
              </a>
              <a className="button button-quiet" href="#about" data-testid="button-about-seema">
                A little about me <ArrowDown size={15} />
              </a>
            </div>
            <div className="hero-meta reveal reveal-delay-3" data-testid="text-hero-status">
              <span><i className="status-dot" /> Open to learning & new opportunities</span>
              <span>WEB + AI / ML</span>
            </div>
          </div>

          <div className="hero-art reveal reveal-delay-2" aria-label="A visual sketch of web and AI code">
            <div className="orbit"><i className="orbit-dot" /></div>
            <div className="code-window">
              <div className="window-top">
                <span className="window-lights"><i /><i /><i /></span>
                <span>seema.visavadiya — portfolio</span>
                <span>•••</span>
              </div>
              <div className="code-lines" aria-label="Sample code illustration">
                <p><span className="code-muted">01</span> <span className="code-purple">const</span> developer = {'{'}</p>
                <p className="indent"><span className="code-cyan">focus</span>: <span className="code-green">'web + AI/ML'</span>,</p>
                <p className="indent"><span className="code-cyan">mindset</span>: <span className="code-green">'learn by building'</span>,</p>
                <p className="indent"><span className="code-cyan">status</span>: <span className="code-green">'just getting started'</span></p>
                <p>{'}'}</p>
                <p>&nbsp;</p>
                <p><span className="code-purple">while</span> (curious) {'{'}</p>
                <p className="indent">buildSomethingUseful(); <span className="code-muted">↗</span></p>
                <p>{'}'}</p>
              </div>
            </div>
            <div className="float-chip chip-one"><Sparkles size={15} /> AI / ML curious</div>
            <div className="float-chip chip-two"><Code2 size={15} /> Web developer</div>
            <div className="float-chip chip-three"><Cpu size={15} /> Builder in progress</div>
          </div>
        </div>
        <span className="scroll-note">Scroll to explore</span>
      </section>

      <section className="section" id="about" data-testid="section-about">
        <div className="section-wrap about-layout">
          <div className="about-monogram reveal" aria-label="Seema Visavadiya monogram">
            <span className="monogram">SV</span>
            <span className="monogram-caption">Learning by building / 01</span>
          </div>
          <div className="about-copy reveal reveal-delay-1">
            <div className="section-heading">
              <div className="eyebrow">About me</div>
              <h2>One curiosity.<br />Two worlds to build in.</h2>
            </div>
            <p data-testid="text-about-description">
              I’m <strong>Seema Visavadiya</strong>, a fresher developer drawn to both the craft of building for the web and the possibilities of artificial intelligence. I enjoy turning new ideas into tangible projects—and learning something real with every build.
            </p>
            <p>
              My work spans web fundamentals, Python, and practical AI/ML experiments. I’m at the beginning of my journey, and I bring the best kind of energy to it: curiosity, care, and a willingness to keep improving.
            </p>
            <div className="about-note">A good project is more than a demo. It makes a technical idea easier to understand—and more useful to someone.</div>
            <div className="about-tags" data-testid="list-about-focus">
              <span className="tag">Build with purpose</span>
              <span className="tag">Stay curious</span>
              <span className="tag">Keep learning</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section skills-section" id="skills" data-testid="section-skills">
        <div className="section-wrap skills-layout">
          <div className="skills-intro reveal">
            <div className="section-heading">
              <div className="eyebrow">Skills & toolkit</div>
              <h2>Foundations<br />with room to grow.</h2>
              <p>Hands-on skills I’m using to bring web experiences and applied AI projects to life.</p>
            </div>
            <a className="text-button" href="#projects" data-testid="link-skills-to-projects">See these skills in action <ArrowRight size={15} /></a>
          </div>
          <div className="skill-list" data-testid="list-skills">
            {skillGroups.map((group, index) => {
              const Icon = group.icon;
              return (
                <article
                  className={`skill-group reveal reveal-delay-${Math.min(index % 3 + 1, 3)}`}
                  key={group.name}
                  data-testid={`card-skill-category-${group.name.toLowerCase().replaceAll(/[^a-z0-9]+/g, '-')}`}
                >
                  <div className="skill-group-heading">
                    <span className="skill-group-icon"><Icon size={18} /></span>
                    <h3>{group.name}</h3>
                  </div>
                  <ul className="skill-tags" aria-label={`${group.name} skills`}>
                    {group.skills.map((skill) => (
                      <li
                        className="skill-tag"
                        key={skill}
                        data-testid={`badge-skill-${skill.toLowerCase().replaceAll(/[^a-z0-9]+/g, '-')}`}
                      >
                        {skill}
                      </li>
                    ))}
                  </ul>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="section" id="projects" data-testid="section-projects">
        <div className="section-wrap">
          <div className="section-heading reveal">
              <div className="eyebrow">My projects</div>
            <h2>Ideas, made tangible.</h2>
            <p>Three projects where web building meets practical artificial intelligence. Open a project to learn more about the idea behind it.</p>
          </div>
          <div className="projects-grid" data-testid="list-projects">
            {projects.map((project, index) => {
              const Icon = project.icon;
              return (
                <article className={`project-card reveal reveal-delay-${index + 1}`} key={project.title} data-testid={`card-project-${index + 1}`}>
                  <div className={`project-art ${project.tone}`}><div className="project-symbol"><Icon size={30} strokeWidth={1.6} /></div></div>
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <div className="project-bottom">
                    <span className="project-stack">{project.stack}</span>
                    <button className="text-button" type="button" onClick={() => setSelectedProject(project)} data-testid={`button-project-details-${index + 1}`}>
                      Project details <ArrowRight size={14} />
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="section skills-section" id="experience" data-testid="section-experience">
        <div className="section-wrap experience-layout">
          <div className="experience-intro reveal">
            <div className="section-heading">
              <div className="eyebrow">Internship experience</div>
              <h2>Learning in the real world.</h2>
              <p>My first professional step into the fast-moving world of AI and machine learning.</p>
            </div>
          </div>
          <article className="experience-card reveal reveal-delay-1" data-testid="card-internship-experience">
            <div className="experience-top">
              <div>
                <h3>AI Intern</h3>
                <div className="experience-company">Integrax Technolab LLP</div>
              </div>
              <span>COMPLETED</span>
            </div>
            <p>Completed an AI internship at Integrax Technolab LLP. This experience is part of my journey as a fresher Web Developer and AI/ML Developer.</p>
          </article>
        </div>
      </section>

      <section className="section contact-section" id="contact" data-testid="section-contact">
        <div className="section-wrap">
          <div className="contact-panel reveal">
            <div className="contact-content">
              <div className="eyebrow">Contact me</div>
              <h2>Have a good idea?<br />Let’s start there.</h2>
              <p>I’m excited to connect about opportunities, collaborations, and meaningful work.</p>
              <div className="contact-actions" data-testid="contact-actions">
                <a
                  className="button button-primary"
                  href="mailto:visavadiyaseema3@gmail.com"
                  data-testid="link-contact-email"
                >
                  <Mail size={17} /> Email Seema
                </a>
                <a
                  className="button button-quiet"
                  href="https://www.linkedin.com/in/seema-visavadiya-506784285"
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="link-contact-linkedin"
                >
                  <Linkedin size={17} /> Connect on LinkedIn <ArrowRight size={15} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="footer" data-testid="site-footer">
        <div className="footer-inner">
          <span>© {new Date().getFullYear()} Seema Visavadiya</span>
          <span>Built with curiosity <span aria-hidden="true">/</span> Web + AI / ML</span>
          <a href="#home" data-testid="link-back-to-top">Back to top ↑</a>
        </div>
      </footer>

      {selectedProject && (
        <div
          className="modal-backdrop"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setSelectedProject(null);
          }}
          data-testid="dialog-project-backdrop"
        >
          <section className="project-modal" role="dialog" aria-modal="true" aria-labelledby="project-modal-title" data-testid="dialog-project-details">
            <button className="modal-close" type="button" aria-label="Close project details" onClick={() => setSelectedProject(null)} data-testid="button-close-project-dialog"><X size={18} /></button>
            <span className="modal-label">{selectedProject.category}</span>
            <h3 id="project-modal-title">{selectedProject.title}</h3>
            <p>{selectedProject.detail}</p>
            <p><strong className="code-cyan">Focus:</strong> {selectedProject.stack}</p>
            <button className="button button-quiet" type="button" onClick={() => setSelectedProject(null)} data-testid="button-return-to-projects">Back to projects</button>
          </section>
        </div>
      )}
    </main>
  );
}

export default App;
